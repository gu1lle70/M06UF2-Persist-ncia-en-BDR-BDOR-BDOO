<?php
$db_server = "localhost";
$db_user = "entich";
$db_pass ="12345";
$db_name = "entich";
?>
